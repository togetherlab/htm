def test_linting():
    import subprocess
    # subprocess.check_output(['flake8', 'tensorboardX'])
